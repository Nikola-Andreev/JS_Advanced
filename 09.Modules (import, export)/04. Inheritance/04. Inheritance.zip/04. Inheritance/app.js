let Person = require('./person')
let Entity = require('./entity')
let Student = require('./student')
let Dog = require('./dog')

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;
